/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.defensesystem;

/**
 *
 * @author supun
 */
interface Observer1 {
    public void updateChat(String name, String msg);
}

interface Observer extends Observer1 {

    public void areaClear(boolean a);

    public void setBtnValue(int value);
}
