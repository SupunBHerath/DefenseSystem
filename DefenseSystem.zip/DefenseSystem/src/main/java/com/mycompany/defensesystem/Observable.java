/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.defensesystem;

import java.util.ArrayList;

/**
 *
 * @author supun
 */
public class Observable {

    ArrayList<Observer> Unit = new ArrayList<Observer>();

    // add data for chathis 
    public void addUnit(Observer ovObserver) {
        Unit.add(ovObserver);
    }

    public void updateChat(String name, String msg) {
        for (Observer ChatHi : Unit) {
            ChatHi.updateChat(name, msg);
        }
    }

    public void updateArea(boolean a) {
        for (Observer unit : Unit) {
            unit.areaClear(a);

        }
    }

    public void updatePositionValue(int value) {
        for (Observer unit : Unit) {
            unit.setBtnValue(value);
        }
    }

}
