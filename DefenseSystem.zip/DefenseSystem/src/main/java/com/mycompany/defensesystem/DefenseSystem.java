/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.defensesystem;

/**
 *
 * @author supun
 */
public class DefenseSystem {

    public static void main(String[] args) {
        Observable observable = new Observable();
        
        observable.addUnit(new MainController("Main Controller" , observable));
        observable.addUnit(new Helicopter("Helicopter" , observable));
        observable.addUnit(new Tank("Tank" , observable));
        observable.addUnit(new Submarine("Submarine" , observable));
        
    }
}
